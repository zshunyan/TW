var numeroAdivinar=Math.floor((Math.random()*100)+1);


function escribirNum(){
//    alert(numeroAdivinar)
    document.getElementById("demo").innerHTML=numeroAdivinar;

}
