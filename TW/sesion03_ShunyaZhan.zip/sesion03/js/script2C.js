var numeroAdivinar=Math.floor((Math.random()*100)+1);

function adivinarNumero(){

    var numero=document.getElementById("numero").value;
    //Ver si es mayor o menor y escribir si es mayor o menor en p

}

